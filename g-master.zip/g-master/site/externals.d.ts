declare module '*.less';

declare module 'ptz-i18n';
