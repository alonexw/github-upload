---
title: Circle 圆形
order: 6
---

# 属性

- 详见 [图形属性](/zh/docs/api/shape/api#属性)；

## attrs 绘图属性

> 通用的 [绘图属性](/en/docs/api/shape/attrs)

### x

- 圆心的 x 坐标；

### y

- 圆心的 y 坐标；

### r

- 圆的半径；
