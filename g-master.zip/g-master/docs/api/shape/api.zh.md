---
title: API 接口
order: 4
---

## 属性

### [元素属性](/zh/docs/api/general/element#属性)

### attrs: Object

- 绘图属性，详见 [绘图属性](/zh/docs/api/shape/attrs) 说明；

## 方法

### [元素方法](/zh/docs/api/general/element#方法)

### isHit(x: number, y: number)

### isClipShape()

- 当前图形是否用于裁剪, 默认为 `false`；
