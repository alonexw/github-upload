---
title: Polygon
order: 11
---

# 属性

- 详见 [图形属性](/en/docs/api/shape/api#属性)；

## attrs 绘图属性

> 通用的 [绘图属性](/en/docs/api/shape/attrs)

### points

- 形如 `[ [ x1, y1 ], [ x2, y2 ], ... ]` 的点集合；
