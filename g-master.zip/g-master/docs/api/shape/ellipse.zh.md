---
title: Ellipse 椭圆
order: 7
---

# 属性

- 详见 [图形属性](/zh/docs/api/shape/api#属性)；

## attrs 绘图属性

> 通用的 [绘图属性](/zh/docs/api/shape/attrs)

### x

- 圆心的 x 坐标；

### y

- 圆心的 y 坐标；

### rx

- 椭圆的水平半径；

### ry

- 椭圆的垂直半径；
