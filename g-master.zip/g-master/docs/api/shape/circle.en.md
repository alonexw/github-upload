---
title: Circle
order: 6
---

# 属性

> 详见 [图形属性](/en/docs/api/shape/api#属性)；

## attrs 绘图属性

> 通用的 [绘图属性](/en/docs/api/shape/attrs)

### x

- 圆心坐标的 x 坐标；

### y

- 圆心坐标的 y 坐标；

### r

- 圆的半径；
