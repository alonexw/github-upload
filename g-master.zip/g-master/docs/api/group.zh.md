---
title: Group 图形分组
order: 3
---

## 属性

### [元素属性](/zh/docs/api/general/element#属性)

### [容器属性](/zh/docs/api/general/container#属性)

## 方法

### [元素方法](/zh/docs/api/general/element#方法)

### [容器方法](/zh/docs/api/general/container#方法)
