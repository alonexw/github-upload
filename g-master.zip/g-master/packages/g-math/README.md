# g-math

> 为 `G` 提供几何图形运算的库


## 安装下载

> tnpm i --save @antv/g-math

```js
// 所有的 api 是都这么引入，名字不同而已
import { line } from '@antv/g-math';

const len = line.length(x1, x2, x2, y2);

```


## API 文档

> 目前使用到的、且推荐使用的 API 文档，不在文档内的不建议使用。



