// 导出 g-base 中的 types
export * from '@antv/g-base';
