---
title: Path
order: 6
---

- Draw path.
