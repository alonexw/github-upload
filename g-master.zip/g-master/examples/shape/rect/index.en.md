---
title: Rect
order: 2
---

- Draw rectangle.
