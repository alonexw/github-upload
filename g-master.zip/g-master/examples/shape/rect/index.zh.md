---
title: Rect 矩形
order: 2
---

- 绘制矩形。
