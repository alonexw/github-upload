---
title: 图形事件
order: 0
---

- 直接在图形 shape 上监听事件。
