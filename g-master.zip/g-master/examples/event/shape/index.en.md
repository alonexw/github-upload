---
title: Shape Event
order: 0
---

- Monitoring events on shape directly.
