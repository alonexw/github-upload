---
title: Event delegation
order: 2
---

- Support event delegation.
