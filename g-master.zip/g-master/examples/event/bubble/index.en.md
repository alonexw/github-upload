---
title: Event bubble
order: 1
---

- Support event bubble and event bubbles from child to its parent step by step.
