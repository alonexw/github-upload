---
title: Attribute animation
order: 0
---

- Add animation by setting final status of attributes' value.
