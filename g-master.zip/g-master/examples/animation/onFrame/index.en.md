---
title: Customize frame animation
order: 1
---

- Customize frame animation by setting frame function.
