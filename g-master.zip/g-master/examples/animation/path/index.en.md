---
title: Path animation
order: 2
---

- Achieve path animation easily by setting frame function where update the position of shape.
