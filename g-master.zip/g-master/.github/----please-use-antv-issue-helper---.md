---
name: '⚠️ Please use https://antv-issue-helper.surge.sh ⚠️'
about: The issue which is not created via https://antv-issue-helper.surge.sh will be closed immediately.
labels:
---

The issue which is not created via https://antv-issue-helper.surge.sh will be closed immediately.

---

注意：不是用 https://antv-issue-helper.surge.sh 创建的 issue 会被立即关闭。
